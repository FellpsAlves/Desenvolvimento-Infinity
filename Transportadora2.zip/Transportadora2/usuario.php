<?php
/*
|-------------------------------------------------------------------
|	CLASSE USUARIO
|-------------------------------------------------------------------
|
*/
class Usuario
{	
	// dados do usuario, caso queiram adicionar mais funcoes como insercao, edicao e etc.
	var $usuario;
	var $senha;
	
	
  
	function logar($login, $senha)
	{
		// conecta ao banco de dados
		require 'banco\conexao.php';
		$conexao = new Conexao();
		$conexao->conecta_bd();

		
		$this->usuario = $login;
		$this->senha = md5($senha);
		
		/**
		 *	Ao invés de procurar o usuário e senha, eu busco apenas a senha, e comparo com o login.
		 *	Caso eu ache uma senha para determinado login, eu vou verificar quantos registros
		 *	foram encontrados.
		 */
		$select = "select senha from usuarios where login = '$login'";
		$query = mysql_query($select);
		$linhas = mysql_num_rows($query);
		$resultado = mysql_fetch_array($query);
		/** 
		 *	Aqui alem de comparar a senha digitada com a senha que foi encontrada no banco.
		 *	eu vejo tambem se foi encontrado apenas um registro.
		 *	isso significa que se o usuário digitar 'or 1 = '1-- no campo senha,
		 *	ele vai comparar: se senhadobanco == "'or 1 = '1--".
		 *	se ele digitou o sql injection tambem no campo usuario, o bd retornara mais de
		 * 	um resultado, portanto tambem nao ira passar na validacao.
		 *	a nao ser é claro que seu banco so tenha apenas um usuario =P
		 */
		if(($this->senha == $resultado['senha']) and ($linhas == 1)):
			// se estiver tudo correto.
			return true;
		else:
			// senao, retorna false.
			return false;
		endif;
	}
	
	/*function conecta_bd()
	{
		$conexao = mysql_connect($this->host, $this->user, $this->pw);
		mysql_select_db($this->db, $conexao);
	}*/
	
}

?>