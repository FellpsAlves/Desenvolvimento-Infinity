
<?php
require_once("config.php");
if(isset($_GET["id"])){
	$id = $_GET["id"];
	$pesquisa = getPesquisa($id);
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Relatório | Infinity Brasl</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main2.css">
	<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		 <div class="container-login100"> 
			<div class="wrap-login100">
				<form class="login100-form validate-form">
					<div style="overflow-x:auto;"> 
						<table class="table">
							<thead class="thead-dark">
								<tr>
									<th scope="col">ID</font></th>
									<th scope="col">MOTORISTA</th>
									<th scope="col">CAVALO</th>
									<th scope="col">CARRETA</th>
									<th scope="col">FILIAL</th>
									<th scope="col">FROTA</th>
									<th scope="col">STATUS</th>
									<th scope="col">DATA INICIAL</th>
									<th scope="col">DATA FINAL</th>
									<th scope="col">DESTINATARIO</th>
									<th scope="col">TEMPO TRANSITO</th>
									<th scope="col">ORIGEM</th>
									<th scope="col">DESTINO</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<?php

											require 'banco\conexao.php';
											$conexao = new Conexao();
											$conexao->conecta_bd();
											$dataInicial = $_POST["dataInicial"];
											$dataFinal = $_POST["dataFinal"];	
											$status = $_POST["status"];
										    $filial = $_POST["filial"];
										    $motorista = $_POST["motorista"];
											getPesquisaLista2($dataInicial, $dataFinal, $status, $filial, $motorista); ?>
										


									?></tr>

								</tbody>
							</table>
						</div>
					</form>
				</div>
			</div>
		</div>



		<!--===============================================================================================-->
		<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
		<!--===============================================================================================-->
		<script src="vendor/animsition/js/animsition.min.js"></script>
		<!--===============================================================================================-->
		<script src="vendor/bootstrap/js/popper.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<!--===============================================================================================-->
		<script src="vendor/select2/select2.min.js"></script>
		<!--===============================================================================================-->
		<script src="vendor/daterangepicker/moment.min.js"></script>
		<script src="vendor/daterangepicker/daterangepicker.js"></script>
		<!--===============================================================================================-->
		<script src="vendor/countdowntime/countdowntime.js"></script>
		<!--===============================================================================================-->
		<script src="js/main.js"></script>

	</body>
	</html>