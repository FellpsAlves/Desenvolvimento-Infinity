<?php

class Conexao
{	

	
	// dados do servidor mysql
    var $host	= 'localhost';
	var $user	= 'root';
	var $pw		= '';
	var $db		= 'transportadora';

	function conecta_bd()
	{
		$conexao = mysql_connect($this->host, $this->user, $this->pw);
		mysql_select_db($this->db, $conexao);
	}

}

?>