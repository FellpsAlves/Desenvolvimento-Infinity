<?php


function getPesquisa($id){
	require 'banco\conexao.php';
	$conexao = new Conexao();
	$conexao->conecta_bd();
	$sql = $pdo->query("SELECT * FROM entregas WHERE id = $id");

	$linha = $sql->fetch(PDO::FETCH_ASSOC);

	return $linha;

}

function getPesquisaLista(){
	$pdo = conectaDB();

	$sql = $pdo->query("SELECT * FROM entregas");

	while($linha = $sql->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>";
		echo "<td>" . $linha["id"] . "</td>";
		echo "<td>" . $linha["motorista"] . "</td>";
		echo "<td>" . $linha["cavalo"] . "</td>";
		echo "<td>" . $linha["carreta"] . "</td>";
		echo "<td>" . $linha["filial"] . "</td>";
		echo "<td>" . $linha["frota"] . "</td>";
		echo "<td>" . $linha["status"] . "</td>";
		echo "<td>" . $linha["dataInicial"] . "</td>";
		echo "<td>" . $linha["dataFinal"] . "</td>";
		echo "<td>" . $linha["tempoTransito"] . "</td>";
		echo "<td>" . $linha["origem"] . "</td>";
		echo "<td>" . $linha["destino"] . "</td>";
		echo "</tr>";
	}
}

function getPesquisaLista2($dataInicial, $dataFinal, $status, $filial, $motorista){
	$pdo = conectaDB();
	$pes = "";
	$aux = False;
	echo "<script>alert('teste'.$aux);</script>";

	if(($dataInicial != "") & ($dataFinal !="")){

		if($dataInicial < $dataFinal){
			$pes = "data BETWEEN " . "'" . $dataInicial ."'" . " AND " . "'" .$dataFinal ."'";
			$aux = True;
		}else{
			echo "<script>alert('DATA FINAL menor que DATA INICIAL');</script>";
			echo "<script>window.location='/Hackathon/admin/index.php';</script>";
		}

		
	 
	}

	if($status != ""){
		if($aux == False){
			$pes = "status LIKE "."'".$status."'";
			$aux = true;
		}else{
			$pes .= " AND status LIKE "."'".$status."'";
		}
		
	}

	if($filial != ""){
		if($aux == false){
			$pes = "filial LIKE "."'".$filial."'";
			$aux = true;
		}else{
			$pes .= " AND filial LIKE "."'".$filial."'";
		}
		
	}

	if($motorista != ""){
		if($aux == false){
			$pes = "motorista LIKE "."'".$motorista."'";
			$aux = true;
		}else{
			$pes .= " AND motorista LIKE "."'".$motorista."'";
		}
		
	}
	
	$sql = $pdo->query("SELECT * FROM entregas WHERE " . $pes . ";");


	while($linha = $sql->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>";
		echo "<td>" . $linha["id"] . "</td>";
		echo "<td>" . $linha["motorista"] . "</td>";
		echo "<td>" . $linha["cavalo"] . "</td>";
		echo "<td>" . $linha["carreta"] . "</td>";
		echo "<td>" . $linha["filial"] . "</td>";
		echo "<td>" . $linha["frota"] . "</td>";
		echo "<td>" . $linha["status"] . "</td>";
		echo "<td>" . $linha["dataInicial"] . "</td>";
		echo "<td>" . $linha["dataFinal"] . "</td>";
		echo "<td>" . $linha["tempoTransito"] . "</td>";
		echo "<td>" . $linha["origem"] . "</td>";
		echo "<td>" . $linha["destino"] . "</td>";
		echo "</tr>";
	}
}
?>