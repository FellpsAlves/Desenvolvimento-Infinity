<?php

require 'usuario.php';

$usuario = new Usuario();

$login = $_POST['login'];
$senha = $_POST['senha'];

if(!$usuario->logar($login, $senha)):
	echo "Erro ao se logar";
else:
	header('Location: formulario.php');
	 $_SESSION["sessiontime"]  = time() + 60;
endif;

?>